Swal.fire(
    'Good job!',
    'You clicked the button!',
    'success'
  )